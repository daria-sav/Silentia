using UnityEngine;

/// <summary>
/// Companion to ReplayRecorder. Records keyframe position and velocity
/// AFTER PlayerMovement has processed forces for this tick.
/// This ensures jump/dash impulses are included in keyframe data,
/// matching what ReplayDriftCorrector sees during playback.
///
/// Execution order: ReplayRecorder (-300) captures input →
/// PlayerMovement (0) processes physics →
/// ReplayLateKeyframer (50) records post-motor keyframe.
/// </summary>
[DefaultExecutionOrder(50)]
public class ReplayLateKeyframer : MonoBehaviour
{
    private bool hasPending;
    private int pendingTick;
    private ReplayClip targetClip;
    private PlayerMovement motor;

    public void ScheduleKeyframe(int tick, ReplayClip clip, PlayerMovement motorRef)
    {
        pendingTick = tick;
        targetClip = clip;
        motor = motorRef;
        hasPending = true;
    }

    private void FixedUpdate()
    {
        if (!hasPending) return;
        hasPending = false;

        if (targetClip == null || motor == null) return;

        Vector2 pos = transform.position;
        Vector2 vel = motor.RB.linearVelocity;

        targetClip.AddKeyframe(pendingTick, pos, vel);
    }
}