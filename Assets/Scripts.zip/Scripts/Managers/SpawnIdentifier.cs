using UnityEngine;

public class SpawnIdentifier : MonoBehaviour
{
    public string spawnKey;
}
