using UnityEngine;

//[DefaultExecutionOrder(-200)]
public class PlayerBrain : MonoBehaviour
{
    private GatherInput input;
    private MultipleJumpAbility jump;
    private DashAbility dash;

    private void Awake()
    {
        input = GetComponent<GatherInput>();
        jump = GetComponent<MultipleJumpAbility>();
        dash = GetComponent<DashAbility>();
    }

    private void FixedUpdate()
    {
        if (input == null) return;

        if (input.jumpDownTick && jump != null)
            jump.TryToJump();

        if (input.dashDownTick && dash != null)
            dash.TryStartDash();

        if (input.jumpDownTick)
            Debug.Log($"GHOST BRAIN {gameObject.name}: saw jumpDownTick");
            Debug.Log($"[BRAIN JUMP {gameObject.name}] tickDown=true state={GetComponent<Player>().stateMachine.currentState} grounded={GetComponent<Player>().physicsControl.isGrounded} coyote={GetComponent<Player>().physicsControl.coyoteTimer:F2} num={jump.DebugNumJumps()} canAdd={jump.DebugCanAdd()}");
    }
}